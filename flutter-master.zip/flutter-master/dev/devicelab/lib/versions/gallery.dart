// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// The pinned version of flutter gallery, used for devicelab tests.
const String galleryVersion = '8542ca8beebc8e989adee160f7f1f0841a734db2';
