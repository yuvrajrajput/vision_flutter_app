# Android custom host app

Android host app for a Flutter module created using
```
$ flutter create -t module hello
```
and placed in a sibling folder to (a clone of) the host app.
Used by the `module_custom_host_app_name_test.dart` device lab test.
